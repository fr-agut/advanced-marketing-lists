﻿<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

function post_install() {
   
   if ($_REQUEST['mode'] == 'Install') {

      // INSTALACION DE LOS REGISTROS DE EJEMPLO 
      // nota: se crea este codigo como script y no como accion porque en la accion post_execute todavia no esta creada la tabla en la base de datos
      
      global $current_user, $db, $sugar_config;
            
      if ($sugar_config['dbconfig']['db_type'] == 'mysql') {
         $record_example_defs = array (
            1 => array (
               'id' => '1',
               'name' => 'Current month Targets and Users',
               'description' => 'Targets and Users created current month',
               'sql_users' => 'SELECT id FROM users WHERE MONTH(date_entered) = MONTH(NOW()) AND YEAR(date_entered) = YEAR(NOW())',
               'sql_prospects' => 'SELECT id FROM prospects WHERE MONTH(date_entered) = MONTH(NOW()) AND YEAR(date_entered) = YEAR(NOW())',
               'modules' => '^Prospects^,^Users^',
               'regenerar_listas' => '0',
               'def_prospect_list_id' => '',
            ),
            2 => array (
               'id' => '2',
               'name' => 'All Targets',
               'description' => 'All Targets',
               'sql_users' => '',
               'sql_prospects' => 'SELECT id FROM prospects',
               'modules' => '^Prospects^',
               'regenerar_listas' => '0',
               'def_prospect_list_id' => '',
            ),            
         );
      }
      else {
         $record_example_defs = array ();
      }


      $fecha_hora = gmdate('Y-m-d H:i:s');
      $fecha = gmdate('Y-m-d');    


      foreach ($record_example_defs as $key => $record_example_def) { 
         $sql = "SELECT count(1) FROM dha_mkt_list WHERE id = '{$record_example_def['id']}' ";
         $cuenta = $db->getOne($sql);
      
         if ($cuenta == 0) {
            $sql = "INSERT INTO dha_mkt_list 
                       (id, date_entered, date_modified, modified_user_id, created_by, deleted, 
                        assigned_user_id, name, 
                        sql_users, sql_prospects, modules, 
                        regenerar_listas, def_prospect_list_id, description)
                    VALUES ('{$record_example_def['id']}', '{$fecha_hora}', '{$fecha_hora}', '{$current_user->id}', '{$current_user->id}', 0, 
                            '{$current_user->id}', '{$record_example_def['name']}', 
                            '{$record_example_def['sql_users']}', '{$record_example_def['sql_prospects']}', '{$record_example_def['modules']}', 
                            {$record_example_def['regenerar_listas']}, '{$record_example_def['def_prospect_list_id']}', '{$record_example_def['description']}') ";
            $db->query($sql);
         }         
      }
   
?>

      <br /><br />

      <div style="margin: 15px;">

      <span style="font-size: 1.7em;"><strong>Advanced Marketing Lists Demo has been installed!</strong></span>

      <p style="margin: 15px 0px 15px 0px; font-size: 1.7em;"><strong>How to start</strong></p>
      
      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      Some examples has been installed by default. 
      Open <a href="index.php?module=DHA_Mkt_List&action=index" target="_blank">&quot;Advanced Marketing Lists&quot;</a> to see them. 
      In &quot;Advanced Marketing Lists&quot; DetailView, press the &quot;Add to TargetList&quot; action/button to fill any Target List selected.
      </p> 
      
      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      In ListView of Targets and Users there is a new shortcut menu &quot;Create Advanced Marketing List from Search&quot;. 
      </p>      

      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      To create new scheduler, go to &quot;Advanced Marketing Lists&quot; DetailView and click "Create Scheduler" link. 
      Remember that you need Admin access and have filled a default Target List (only for schedulers) to see this link.
      </p> 
      
      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      Please also read <b>User Guide.pdf</b> and <b>readme.txt</b> (in zip installation file) before using &quot;Advanced Marketing Lists&quot;.
      </p>            
      
      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      <strong>Enjoy!!</strong>
      </p>         

      <p style="margin: 15px 0px 15px 0px; font-size: 1.7em;"><strong>Contact</strong></p> 
      <p style="margin: 15px 0px 15px 0px; font-size: 1.25em; line-height: 1.5em; width: 700px;">
      Izertis<br />
      <a href="mailto:soportesigi@izertis.com">soportesigi@izertis.com</a><br />
      <a href="http://www.sigisoftware.com" target="_blank">www.sigisoftware.com</a><br />
      </p>

      </div>
      
      <br /><br />

<?php
   }

}

?>

