<?php

require_once('include/MVC/View/views/view.detail.php');

class DHA_Mkt_ListViewDetail extends ViewDetail  {

   ///////////////////////////////////////////////////////////////////////////////////////////////////   
   function __construct(){
   
      parent::__construct();  
   }
   
   ///////////////////////////////////////////////////////////////////////////////////////////////////   
   public function preDisplay() {

      $this->bean->scheduler_url = $this->bean->get_scheduler_url();
      $this->bean->scheduler_html = $this->bean->get_scheduler_html();

      parent::preDisplay();    
   }   

   ///////////////////////////////////////////////////////////////////////////////////////////////////      
   public function display() { 
      
      parent::display();  
   }
}  
?>
