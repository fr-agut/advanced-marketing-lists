<?php

require_once('include/MVC/View/views/view.edit.php');

class DHA_Mkt_ListViewEdit extends ViewEdit {

   ///////////////////////////////////////////////////////////////////////////////////////////////////   
   function __construct(){
      parent::__construct();
      
      $this->useForSubpanel = true;         
   }
   
   
   ///////////////////////////////////////////////////////////////////////////////////////////////////         
   function get_script_sql_validations() { 
      // Nota: jQuery se incluye en SugarCRM desde la version 6.5
   
      if ($this->ev->view == 'EditView') {  
         $form_name = 'EditView';  
      }     
      elseif ($this->ev->view == 'QuickCreate') {     
         $form_name = 'form_SubpanelQuickCreate_DHA_Mkt_List';  
      }  
      
      $javascript=<<<EOQ
         <script type="text/javascript" language="JavaScript">
         
            function sql_replaceAll(sql, busca, reemplaza ){
               while (sql.indexOf(busca) != -1)
                  sql = sql.replace(busca, reemplaza);
               return sql;
            }              
         
            function validate_sql_field(input, field_name, module) {
               ajaxStatus.showStatus('Validating');
               
               var OK = true;
               var ajaxValidationMsg = "";
               
               var sql = String(input.value);
               sql = sql_replaceAll (sql, '+', '%2B'); 
               sql = sql_replaceAll (sql, '&', '%26'); 
               
               var dataString = 'field_name=' + field_name + '&sql=' + sql;
               jQuery.ajax({
                     url: "index.php?module=DHA_Mkt_List&action=ValidateSQL",
                     global: false,
                     type: "POST",
                     data: dataString,
                     dataType: "text",
                     timeout: 20000,
                     async: false,   // synchronous !!!
                     success: function(data, textStatus, XMLHttpRequest){
                        ajaxValidationMsg = data; 
                        if (!ajaxValidationMsg == "") {
                           OK = false;
                        }
                     },
                     error: function(XMLHttpRequest, textStatus, errorThrown){
                        ajaxValidationMsg = 'AJAX validation fail: ' + textStatus;   
                        OK = false;
                     }         
                  }
               );

               ajaxStatus.hideStatus();
               return OK;
            }
            
            function validate_sql_prospects() { 
               return validate_sql_field ({$form_name}.sql_prospects, 'sql_prospects', 'Prospects');  
            }    
            function validate_sql_users() { 
               return validate_sql_field ({$form_name}.sql_users, 'sql_users', 'Users');  
            } 

            var sql_ajaxValidationMsg = SUGAR.language.get('DHA_Mkt_List', 'LBL_SQL_RULES');        

            addToValidateCallback('{$form_name}', 'sql_prospects', 'text', false, sql_ajaxValidationMsg, validate_sql_prospects);
            addToValidateCallback('{$form_name}', 'sql_users', 'text', false, sql_ajaxValidationMsg, validate_sql_users);
            
         </script>
EOQ;
      
      return $javascript;
   }
   
   ///////////////////////////////////////////////////////////////////////////////////////////////////   
   public function preDisplay() {
   
      // En prospectlists hay una circunstancia especial con los borrados, y es que se ha anulado el codigo
      // de la función mark_relationships_deleted en el bean del modulo. Esto tiene como consecuencia que no se 
      // ponen a nulo los registros de los campos relacionados. Tenemos que tener en cuenta esa circunstancia
      // al cargar los datos del bean, por si el posible registro relacionado estuviera borrado.
      
      if (isset($this->bean->def_prospect_list_id) && $this->bean->def_prospect_list_id) {
         $sql = " SELECT count(1) FROM prospect_lists WHERE id = '{$this->bean->def_prospect_list_id}' AND deleted = 0 ";
         $count = $GLOBALS['db']->getOne($sql);
         if (!$count) {
            $this->bean->def_prospect_list_id = '';
            $this->bean->def_prospect_list = '';
         }
      }
      
      // Si venimos desde la accion de crear registro desde un listview ...
      if (isset($_REQUEST['massupdate']) && $_REQUEST['massupdate'] == 'true' && isset($_REQUEST['current_query_by_page'])) {
         $modulo = $_REQUEST['return_module'];         
         $tabla = strtolower($modulo);   

         $modulo_empleados = false;
         if ($tabla == 'employees') {
            $modulo = 'Users';
            $tabla = 'users';
            $modulo_empleados = true;
         }         
         
         $bean = SugarModule::get($modulo)->loadBean();
         require_once ("include/MassUpdate.php");
         $mass = new MassUpdate();
         $mass->setSugarBean($bean);
         $mass->generateSearchWhere($modulo, $_REQUEST['current_query_by_page']);
           
         $order_by = '';
         $searchFields = '';
         if (isset($mass->searchFields))
            $searchFields = $mass->searchFields;
         $where_clauses = '';
         if (isset($mass->where_clauses))         
            $where_clauses = $mass->where_clauses;
         $use_old_search = '';
         if (isset($mass->use_old_search))         
            $use_old_search = $mass->use_old_search;   

         unset($mass);              
         
         if ($where_clauses) {
            $params = array();  // array('distinct'=>true);
            $query = $bean->create_new_list_query($order_by, $where_clauses, array(), $params, 0, '', false, null, true, true);
            
            $pos = strpos($query, ' FROM ');
            if ($pos !== false) {
               $query = "SELECT {$tabla}.id " . substr($query, $pos);
            }
            
            if ($modulo_empleados) {
               // Add in code to remove portal/group/hidden users
               $query = $query . ' AND users.show_on_employees = 1 AND users.portal_only = 0 AND (users.is_group = 0 or users.is_group is null) ';
            }
         }
         else {
            $query = "SELECT id FROM {$tabla} WHERE deleted = 0 ";
             
            if ($modulo_empleados) {
               // Add in code to remove portal/group/hidden users
               $query = $query . ' AND show_on_employees = 1 AND portal_only = 0 AND (is_group = 0 or is_group is null) ';
            }            
         }

         $sql_field = 'sql_' . $tabla;
         $this->bean->$sql_field = $query;
         
         
         // Usuario asignado
         global $current_user;
         $_REQUEST['assigned_user_id'] = $current_user->id;
         $_REQUEST['assigned_user_name'] = $current_user->user_name;
         
         // Para ir al detalle una vez creado, en lugar de volver a la ventana original de la llamada
         $_REQUEST['return_module'] = 'DHA_Mkt_List';
         $_REQUEST['return_action'] = 'DetailView';
      }
      
      parent::preDisplay();    
   }   

   ///////////////////////////////////////////////////////////////////////////////////////////////////      
   public function display() { 
      
      parent::display();  
      
      echo $this->get_script_sql_validations();     
      
   }
}  
?>
