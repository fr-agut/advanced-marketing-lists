<?php

global $app_list_strings, $app_strings;

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Asignado a Usuario con Id',
  'LBL_ASSIGNED_TO_NAME' => 'Usuario',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Fecha de Creación',
  'LBL_DATE_MODIFIED' => 'Última Modificación',
  'LBL_MODIFIED' => 'Modificado Por',
  'LBL_MODIFIED_ID' => 'Modificado Por Id',
  'LBL_MODIFIED_NAME' => 'Modificado Por Nombre',
  'LBL_CREATED' => 'Creado Por',
  'LBL_CREATED_ID' => 'Creado Por Id',
  'LBL_DESCRIPTION' => 'Descripción',
  'LBL_DELETED' => 'Eliminado',
  'LBL_NAME' => 'Nombre',
  'LBL_CREATED_USER' => 'Creado Por Usuario',
  'LBL_MODIFIED_USER' => 'Modificado Por Usuario',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_FORM_TITLE' => 'Lista Marketing Avanzado',
  'LBL_MODULE_NAME' => 'Lista Marketing Avanzado',
  'LBL_MODULE_TITLE' => 'Lista Marketing Avanzado',
  'LBL_HOMEPAGE_TITLE' => 'Mis Listas Marketing Avanzado',
  'LNK_NEW_RECORD' => 'Crear Lista Marketing Avanzado',
  'LNK_LIST' => 'Vista Lista Marketing Avanzado',
  'LNK_IMPORT_DHA_Lista Marketing Avanzado' => 'Importar Lista Marketing Avanzado',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Lista Marketing Avanzado',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Ver Historial',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_DHA_MKT_LIST_SUBPANEL_TITLE' => 'Lista Marketing Avanzado',
  'LBL_NEW_FORM_TITLE' => 'Nueva Lista Marketing Avanzado',
  'LBL_SQL_PROSPECTS' => 'SQL Público Objetivo',
  'LBL_SQL_USERS' => 'SQL Usuarios',
  'LBL_MODULES' => 'Módulos',
  'LBL_CREATE_NEW_ADVANCED_MKT_LIST' => 'Crear Lista Marketing Avanzado desde Búsqueda',
  
  'LBL_PANEL_SCHEDULER' => 'Planificador',
  'LBL_SCHEDULER' => 'Planificador',
  'LBL_CREATE_SCHEDULER' => 'Crear Planificador',  
  'LBL_VIEW_SCHEDULER' => 'Ver Planificador',   
  'LBL_DEFAULT_PROSPECT_LIST' => 'Lista de Público Objetivo',  
  'LBL_ONLY_FOR_SCHEDULERS' => 'Sólo para Planificadores',  
  'LBL_SCHEDULER_URL' => 'URL para Planificadores',  
  
  'LBL_REGENERAR_LISTA_PUBLICO_OBJETIVO' => 'Regenerar Lista de Público Objetivo',
  'LBL_REGENERAR_LISTA_PUBLICO_OBJETIVO_HELP' => 'Marcando esta opción se borrará el contenido y volverá a generarse completamente la Lista de Público Objetivo seleccionada en el proceso "'.$app_strings['LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL'].'"',
  
  'LBL_ETIQUETA_INSTRUCCIONES_LISTVIEW' => 'Instrucciones',
  'LBL_TEXTO_INSTRUCCIONES_LISTVIEW' => 'Si el proceso "{0}" se ejecuta desde el ListView, tomará el valor del campo "{1}" que coincida en todos los registros seleccionados.<br />
Si hubiera alguno de ellos con un valor distinto a los demás se asumirá que "{2}" se encuentra marcado para todos los registros seleccionados.',
  
  'LBL_PANEL_SQL' => 'SQL',
  'LBL_PANEL_PROSPECTLISTS' => 'Listas de Público Objetivo modificadas', 
  'LBL_PANEL_PROSPECTS' => 'Público Objetivo',
  'LBL_PANEL_USERS' => 'Usuarios',
  
  'LBL_ERROR_SQL_EXECUTE' => 'La SQL para el Módulo "{0}" contiene errores, no puede ejecutarse.',
  'LBL_SQL_RULES' => '<br />La SQL debe de cumplir las siguientes condiciones:<br />
- No se admiten SQL con acciones de tipo INSERT o DELETE. Únicamente SQL de tipo SELECT.<br />
- La sentencia SELECT debe ser siempre sobre la tabla a la que corresponda el campo de SQL.<br />
- La sentencia debe de devolver exclusivamente el campo "id" de la tabla a la que corresponda el campo de SQL.<br />
- La SQL no debe de contener la cláusula "ORDER BY".<br />
- La SQL debe de ejecutarse sin errores.<br />',
);
?>
