<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//function post_uninstall() {

   if ($_REQUEST['mode'] == 'Uninstall') {

      // SE ANULA EL BORRADO, POR COMPATIBILIDAD CON SUGAR ON-DEMAND
/*         
      // BORRADO DE LOS ICONOS
      $ficheros = array (
         'custom/themes/default/images/CreateDHA_Mkt_List.png',
         'custom/themes/default/images/DHA_Mkt_List.png',
         'custom/themes/default/images/icon_DHA_Mkt_List.png',
         'custom/themes/default/images/icon_DHA_Mkt_List_32.png',
      );
      foreach ($ficheros as $fichero) {
         $fichero = getcwd() . "/" . $fichero;
         @unlink ($fichero);
      }
*/        
      
      // BORRADO DE PLANIFICADORES
      if (isset($GLOBALS['mi_remove_tables']) && $GLOBALS['mi_remove_tables']) {
         $sql = "DELETE FROM job_queue WHERE target like '%DHA_SchedulerSaveProspectList%' ";
         $GLOBALS['db']->query($sql);   
         $sql = "DELETE FROM schedulers WHERE job like '%DHA_SchedulerSaveProspectList%' ";
         $GLOBALS['db']->query($sql);
      }
      else {
         $sql = "UPDATE schedulers SET status = 'Inactive' WHERE job like '%DHA_SchedulerSaveProspectList%' ";
         $GLOBALS['db']->query($sql);      
      }
      
      
      // REPAIR & REBUILD
      // require_once("modules/Administration/QuickRepairAndRebuild.php");
      // $rac = new RepairAndClear();
      // $rac->repairAndClearAll(array('clearAll'), array(translate('LBL_ALL_MODULES')), false, false);  
   }   
//}
  
?>
