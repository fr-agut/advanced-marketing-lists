<?php
$dictionary["dha_mkt_lists_prospectlists"] = array (
  'true_relationship_type' => 'many-to-many',
  'relationships' => 
  array (
    'dha_mkt_lists_prospectlists' => 
    array (
      'lhs_module' => 'DHA_Mkt_List',
      'lhs_table' => 'dha_mkt_list',
      'lhs_key' => 'id',
      'rhs_module' => 'ProspectLists',
      'rhs_table' => 'prospect_lists',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'dha_mkt_lists_prospectlists',
      'join_key_lhs' => 'dha_mkt_list_ida',
      'join_key_rhs' => 'prospectlist_idb',
    ),
  ),
  'table' => 'dha_mkt_lists_prospectlists',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'dha_mkt_list_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'prospectlist_idb',
      'type' => 'varchar',
      'len' => 36,
    ),   
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'dha_mkt_lists_prospectlists_pk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'dha_mkt_lists_prospectlists_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'dha_mkt_list_ida',
        1 => 'prospectlist_idb',
      ),
    ),
  ),
);

?>