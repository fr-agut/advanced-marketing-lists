﻿// **************************************//
// How to start                          //
// **************************************//

Please read the AdvancedMarketingListsUserGuide.pdf file before using "Advanced Marketing Lists". You can download this file from SugarForge.

Some examples will be installed by default. Open "Advanced Marketing Lists" to see them. 
In "Advanced Marketing List" DetailView, press the "Add to TargetList" action/button to fill any Target List selected.

In ListView of Contacts, Accounts, Leads, Targets and Users there is a new shortcut menu "Create Advanced Marketing List from Search" (in Demo version, only for Targets and Users ListView).
NOTE: This functionality is not yet available for Sugar 7.2.

To create new scheduler, go to "Advanced Marketing Lists" DetailView and click "Create Scheduler" link. 
Remember that you need Admin access and have filled a default Target List (only for schedulers) to see this link.


// **************************************//
// Demo version limitations              //
// **************************************//

The following features are limited in demo version:

  - SQL fields only for Targets and Users module. Premium version has SQL fields for Contacts, Accounts, Leads, Targets and Users.
  - The process "Add to TargetList" is limited to 20 records.
  - The process "Create Advanced Marketing List from Search" only for Targets and Users module. Premium version supports Contacts, Accounts, Leads, Targets and Users modules.
    NOTE: This functionality is not yet available for Sugar 7.2.
  
  
// **************************************//
// SugarCRM 7 Notes                      //
// **************************************//

- Perform a Repair and Rebuild always after install the component.
  Then empty browser cache (You can use the browser utility or some extension, i.e. "Empty Cache Button" for Firefox, https://addons.mozilla.org/en-us/firefox/addon/empty-cache-button or "Clear Cache" for Chrome, https://chrome.google.com/webstore/detail/clear-cache/cppjkneekbjaeellbfkmgnhonkkjfpdn ).
  Finally refresh Sugar window in the browser.
  This is necessary in order to generate URLs correctly in bwc mode for DetailView and EditView links in ListView.
      
  
// **************************************//
// Compatibility                         //
// **************************************//

Starting from version 1.1.2, the component is compatible with SugarCRM PRO.
From version 1.1.3 is compatible with SugarCRM On-Demand.
From version 1.1.4 is compatible with SugarCRM 7.2.

  
//**************************************//
// Known Issues
//**************************************//

- With SugarCRM PRO version, menu "Create Advanced Marketing List from Search" in ListView of Contacts, Accounts, Leads, Targets and Users, only appears when you press the search button. 
  With CE version this works well.
  NOTE: This functionality is not yet available for Sugar 7.2.

  
// **************************************//
// Contact                               //
// **************************************//

Izertis
soportesigi@izertis.com
www.sigisoftware.com

