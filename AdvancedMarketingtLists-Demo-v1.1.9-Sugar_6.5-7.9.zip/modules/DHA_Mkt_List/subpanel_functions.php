<?php


   ///////////////////////////////////////////////////////////////////////////////////////////////////   
   function get_mkt_list_subpanel_query($parameters = array()) {  
      $sql = from_html($parameters['sql']);  

      $return_array['select']= " SELECT id ";
      $return_array['from']=   " FROM " . $parameters['table'];
      $return_array['join'] =  " ";
      $return_array['where']=  " WHERE {$parameters['table']}.deleted = 0 and {$parameters['table']}.id IN ({$sql}) ";       
      
      // Si no se pone lo siguiente el codigo da un error :
      // PHP Notice:  Undefined index:  join_tables in .....
      $return_array['join_tables'][0] = '';

      if (isset($parameters) and isset($parameters['return_as_array']) && $parameters['return_as_array'] === true) {
         return $return_array;
      }

      return $return_array['select'] . $return_array['from'] . $return_array['join'] . $return_array['where'] ;
   }       


    
?>