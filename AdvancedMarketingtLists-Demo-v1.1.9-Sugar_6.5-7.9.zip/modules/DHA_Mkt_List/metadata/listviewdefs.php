<?php
$module_name = 'DHA_Mkt_List';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '15%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'REGENERAR_LISTAS' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_REGENERAR_LISTA_PUBLICO_OBJETIVO',
    'width' => '10%',
    'default' => true,
  ),  
  'MODULES' => 
  array (
    'type' => 'multienum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_MODULES',
    'width' => '15%',
  ), 
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '20%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '5%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'default' => true,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'type' => 'relate',
    'link' => 'modified_user_link',
    'label' => 'LBL_MODIFIED_NAME',
    'width' => '5%',
    'default' => true,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '5%',
    'default' => true,
  ),
   
  'SQL_PROSPECTS' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_SQL_PROSPECTS',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  'SQL_USERS' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_SQL_USERS',
    'sortable' => false,
    'width' => '10%',
    'default' => false,
  ),
  
  'DEF_PROSPECT_LIST' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_DEFAULT_PROSPECT_LIST',
    'width' => '10%',
    'default' => false,
    'link' => true,
    'id'      => 'DEF_PROSPECT_LIST_ID',
    'related_fields' => array('def_prospect_list_id'),
    'module'  => 'ProspectLists',       
  ),    
 
  
);
?>
