<?php
$module_name = 'DHA_Mkt_List';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (      
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 
          array (
              'customCode' => '{if $bean->ACLAccess_ProspectLists("edit")} 
                                   <input title="{$APP.LBL_ADD_TO_PROSPECT_LIST_BUTTON_TITLE}" class="button" type="button" onclick="open_popup_ProspectLists();"  value="{$APP.LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL}">
                               {/if}',                               
              'sugar_html' => array(
                  'type' => 'button',
                  'value' => '{$APP.LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL}',
                  'htmlOptions' => array(
                      'title' => '{$APP.LBL_ADD_TO_PROSPECT_LIST_BUTTON_TITLE}',
                      'class' => 'button',
                      'onclick' => 'open_popup_ProspectLists();',
                      'name' => 'button_SaveProspectList',
                      'id' => 'button_SaveProspectList',
                  ),
                  'template' => '{if $bean->ACLAccess_ProspectLists("edit")}[CONTENT]{/if}',
               ),
          ),          
        ),
      ),
      'includes'=> array(
         array('file'=>'modules/DHA_Mkt_List/DHA_Mkt_List.js'),
      ),        
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
          ),
          1 => 
          array (
            'name' => 'regenerar_listas',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'description',
          ),
          1 => 
          array (
            'name' => 'modules',
          ),          
        ),       
        2 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'label' => 'LBL_DATE_ENTERED',            
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'label' => 'LBL_DATE_MODIFIED',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
          ),
        ),        
      ),
      
      'LBL_PANEL_SQL' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'sql_prospects',
          ),
          1 => 
          array (
            'name' => 'sql_users',
          ),
        ),
      ),        
      
      'LBL_PANEL_SCHEDULER' => 
      array(
        0 => 
        array (
          0 => 
          array (
            'name' => 'scheduler_html',
          ),                      
          1 => 
          array (
            'name' => 'def_prospect_list',
            'customLabel' => '{sugar_translate label=\'LBL_DEFAULT_PROSPECT_LIST\' module=$fields.parent_type.value}<br /><span style="font-style:oblique; text-decoration:underline; color:black;"> ({sugar_translate label=\'LBL_ONLY_FOR_SCHEDULERS\' module=$fields.parent_type.value}) </span>',
          ),  
        ),     
      ),            
      
    ),
  ),
);
?>
