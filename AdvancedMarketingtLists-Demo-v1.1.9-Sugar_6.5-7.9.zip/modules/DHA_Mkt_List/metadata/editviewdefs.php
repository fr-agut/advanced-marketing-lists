<?php
$module_name = 'DHA_Mkt_List';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'name',
          ),
          1 => 
          array (
            'name' => 'regenerar_listas',
          ),              
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'description',
          ),
          1 => '',           
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),           
        ),        
      ),
      
      'LBL_PANEL_SQL' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'sql_prospects',
          ),
          1 => 
          array (
            'name' => 'sql_users',
          ),
        ),
      ),  

      'LBL_PANEL_SCHEDULER' => 
      array(
        0 => 
        array (
          0 => 
          array (
            'name' => 'def_prospect_list',
            //'label' => 'LBL_DEFAULT_PROSPECT_LIST_EXTENDED',
            'customLabel' => '{sugar_translate label=\'LBL_DEFAULT_PROSPECT_LIST\' module=$fields.parent_type.value}<br /><span style="font-style:oblique; text-decoration:underline; color:black;"> ({sugar_translate label=\'LBL_ONLY_FOR_SCHEDULERS\' module=$fields.parent_type.value}) </span>',
          ),  
          1 => '',              
        ), 
      ),        

    ),
  ),
);
?>
