<?php

$moduleName = 'DHA_Mkt_List';
$viewdefs[$moduleName]['base']['menu']['header'] = array(
   array(
      'route' => '#bwc/index.php?' . http_build_query(
         array(
            'module' => $moduleName,
            'action' => 'EditView',
            'return_module' => $moduleName,
            'return_action' => 'DetailView',
         )
      ),
      'label' => 'LNK_NEW_RECORD',
      'acl_action' => 'create',
      'acl_module' => $moduleName,
      'icon' => 'icon-plus',
   ),
   array(
      'route' => '#' . $moduleName,
      'label' => 'LNK_LIST',
      'acl_action' => 'list',
      'acl_module' => $moduleName,
      'icon' => 'icon-reorder',
   ),
   array(
      'route' => '#bwc/index.php?' . http_build_query(
         array(
            'module' => 'Import',
            'action' => 'Step1',
            'import_module' => $moduleName,
            'query' => 'true',
            'report_module' => $moduleName,
         )
      ),
      'label' => 'LBL_IMPORT',
      'acl_action' => 'import',
      'acl_module' => $moduleName,
      'icon' => 'icon-upload',
   ),
);
