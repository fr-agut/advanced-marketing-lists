<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.list.php');

class DHA_Mkt_ListViewList extends ViewList {

   ///////////////////////////////////////////////////////////////////////////////////////////////////
   function __construct() {
      parent::__construct();
   }
   
   ///////////////////////////////////////////////////////////////////////////////////////////////////   
   public function preDisplay() {
      parent::preDisplay();

      $this->lv->mergeduplicates = false;

      if ( ACLController::checkAccess('ProspectLists','edit',true) ) {
         $this->lv->actionsMenuExtraItems[] = $this->buildTargetList();
      }      
   }   

   ///////////////////////////////////////////////////////////////////////////////////////////////////   
   protected function buildTargetList() {
      
      global $app_strings;
      unset($_REQUEST[session_name()]);
      unset($_REQUEST['PHPSESSID']);
      $current_query_by_page = base64_encode(serialize($_REQUEST));

      $modulo = 'DHA_Mkt_List';

      $js = <<<EOF
            if(sugarListView.get_checks_count() < 1) {
                alert('{$app_strings['LBL_LISTVIEW_NO_SELECTED']}');
                return false;
            }
         if ( document.forms['targetlist_form'] ) {
            var form = document.forms['targetlist_form'];
            form.reset;
         } else {
            var form = document.createElement ( 'form' ) ;
         }
         form.setAttribute ( 'name' , 'targetlist_form' );
         form.setAttribute ( 'method' , 'post' ) ;
         form.setAttribute ( 'action' , 'index.php' );
         document.body.appendChild ( form ) ;
         if ( !form.module ) {
             var input = document.createElement('input');
             input.setAttribute ( 'name' , 'module' );
             input.setAttribute ( 'value' , '{$modulo}' );
             input.setAttribute ( 'type' , 'hidden' );
             form.appendChild ( input ) ;
             var input = document.createElement('input');
             input.setAttribute ( 'name' , 'action' );
             input.setAttribute ( 'value' , 'ListViewSaveProspectList' );
             input.setAttribute ( 'type' , 'hidden' );
             form.appendChild ( input ) ;
         }
         if ( !form.uids ) {
             var input = document.createElement('input');
             input.setAttribute ( 'name' , 'uids' );
             input.setAttribute ( 'type' , 'hidden' );
             form.appendChild ( input ) ;
         }
         if ( !form.prospect_list ) {
             var input = document.createElement('input');
             input.setAttribute ( 'name' , 'prospect_list' );
             input.setAttribute ( 'type' , 'hidden' );
             form.appendChild ( input ) ;
         }
         if ( !form.return_module ) {
             var input = document.createElement('input');
             input.setAttribute ( 'name' , 'return_module' );
             input.setAttribute ( 'type' , 'hidden' );
             form.appendChild ( input ) ;
         }
         if ( !form.return_action ) {
             var input = document.createElement('input');
             input.setAttribute ( 'name' , 'return_action' );
             input.setAttribute ( 'type' , 'hidden' );
             form.appendChild ( input ) ;
         }
         if ( !form.select_entire_list ) {
             var input = document.createElement('input');
             input.setAttribute ( 'name' , 'select_entire_list' );
             input.setAttribute ( 'value', document.MassUpdate.select_entire_list.value);
             input.setAttribute ( 'type' , 'hidden' );
             form.appendChild ( input ) ;
         }
         if ( !form.current_query_by_page ) {
             var input = document.createElement('input');
             input.setAttribute ( 'name' , 'current_query_by_page' );
             input.setAttribute ( 'value', '{$current_query_by_page}' );
             input.setAttribute ( 'type' , 'hidden' );
             form.appendChild ( input ) ;
         }      
         open_popup('ProspectLists','600','400','',true,false,{ 'call_back_function':'set_return_and_save_targetlist','form_name':'targetlist_form','field_to_name_array':{'id':'prospect_list'} } );
EOF;
      $js = str_replace(array("\r","\n"),'',$js);
      
      return "<a href='javascript:void(0)' onclick=\"$js\">{$app_strings['LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL']}</a>";
   } 

   
   ///////////////////////////////////////////////////////////////////////////////////////////////////     
   public function display() {
      parent::display();
   }   
   
}
?>