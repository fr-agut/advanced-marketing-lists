<?php
   if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

      ///////////////////////////////////////////////////////////////////////////////////////////////////      
      function ObtenerIds ($modulo){
         
         global $db;
         
         $recordIds = array();
         
         if(isset($_REQUEST['select_entire_list']) && $_REQUEST['select_entire_list'] == '1'){

            $bean = SugarModule::get($modulo)->loadBean();

            require_once ("include/MassUpdate.php");
            $mass = new MassUpdate();
            $mass->setSugarBean($bean);
            $mass->generateSearchWhere($modulo, $_REQUEST['current_query_by_page']);  
            
            $order_by = '';            
            $searchFields = '';
            if (isset($mass->searchFields))
               $searchFields = $mass->searchFields;
            $where_clauses = '';
            if (isset($mass->where_clauses))         
               $where_clauses = $mass->where_clauses;
            $use_old_search = '';
            if (isset($mass->use_old_search))         
               $use_old_search = $mass->use_old_search;   

            unset($mass);              
            
            $query = $bean->create_new_list_query($order_by, $where_clauses, array(), array(), 0, '', false, null, true, true);
            $dataset = $db->query($query, true);

            while($val = $db->fetchByAssoc($dataset, false)) {
               array_push($recordIds, $val['id']);
            }            
         }
         else if ( !empty($_REQUEST['uids']) ) {
            $recordIds = explode(',',$_REQUEST['uids']);
         }

         return $recordIds;      
      } 
      
      
      ///////////////////////////////////////////////////////////////////////////////////////////////////      
      function getRegenerarListas (&$ids_mkt_list){
         global $db;
         
         $resultado = false;
         
         if (count ($ids_mkt_list > 0)) { 
            $condicion_ids = implode("','", $ids_mkt_list);
            $sql = " SELECT regenerar_listas FROM dha_mkt_list WHERE id IN ('{$condicion_ids}') and deleted = 0 ";
            
            $cont = 1;
            $dataset = $db->query($sql);
            while ($row = $db->fetchByAssoc($dataset)) {
               if ($cont == 1) {
                  $resultado = $row['regenerar_listas'];
               }
               else {
                  if ($resultado != $row['regenerar_listas']) {
                     $resultado = true;
                     break;
                  }
               }
               $cont += 1;
            }            
         }
         
         return (boolean)$resultado;
      }


   ///////////////////////////////////////////////////////////////////////////////////////////////////  

   global $db, $current_user;

   $id_prospect_list = $_REQUEST['prospect_list'];
   $ids_mkt_list = ObtenerIds('DHA_Mkt_List');
   
   
   $bean_ProspectLists = SugarModule::get('ProspectLists')->loadBean();
   $OK = $bean_ProspectLists->retrieve($id_prospect_list);
      
   $is_owner = true;
   if ($current_user->id) {
      $is_owner = $bean_ProspectLists->isOwner($current_user->id);
   }
      
   if($OK && !$bean_ProspectLists->ACLAccess('edit', $is_owner)){
      $OK = false;
   }

   if($OK) {
      $regenerar_listas = getRegenerarListas ($ids_mkt_list);
      if ($regenerar_listas) {
         $sql = "DELETE FROM prospect_lists_prospects WHERE prospect_list_id = '{$id_prospect_list}'";
         $db->query($sql);
      }      
      $_REQUEST['regenerar_listas'] = false; 
   }
   
   if($OK) {
      $bean_Mkt_List = SugarModule::get('DHA_Mkt_List')->loadBean();  
      foreach ($ids_mkt_list as $Id) {
         $bean_Mkt_List->SaveProspectList($Id, $id_prospect_list);
      } 
   }   

   require_once 'include/formbase.php';
   handleRedirect();
   exit;
?>
