﻿// **************************************//
// How to start                          //
// **************************************//

Please read the AdvancedMarketingListsUserGuide.pdf file before using "Advanced Marketing Lists". You can download this file from SugarForge.

Some examples will be installed by default. Open "Advanced Marketing Lists" to see them. 
In "Advanced Marketing List" DetailView, press the "Add to TargetList" action/button to fill any Target List selected.

In ListView of Contacts, Accounts, Leads, Targets and Users there is a new shortcut menu "Create Advanced Marketing List from Search" (in Demo version, only for Targets and Users ListView).
For SugarCRM 7.x this will be a button in ListView instead a shortcut menu, and Users module will not have this functionality.
This functionality is not available for SugarCRM 7.x in Demo version

To create new scheduler, go to "Advanced Marketing Lists" DetailView and click "Create Scheduler" link. 
Remember that you need Admin access and have filled a default Target List (only for schedulers) to see this link.


// **************************************//
// Demo version limitations              //
// **************************************//

The following features are limited in demo version:

  - SQL fields only for Targets and Users module. Premium version has SQL fields for Contacts, Accounts, Leads, Targets and Users.
  - The process "Add to TargetList" is limited to 20 records.
  - The process "Create Advanced Marketing List from Search" only for Targets and Users module. Premium version supports Contacts, Accounts, Leads, Targets and Users modules.
    This functionality is not available for Sugar 7.x in Demo version.
  
  
// **************************************//
// SugarCRM 7 Notes                      //
// **************************************//

- Perform a Repair and Rebuild always after install the component.
  Then empty browser cache (You can use the browser utility or some extension, i.e. "Empty Cache Button" for Firefox, https://addons.mozilla.org/en-us/firefox/addon/empty-cache-button or "Clear Cache" for Chrome, https://chrome.google.com/webstore/detail/clear-cache/cppjkneekbjaeellbfkmgnhonkkjfpdn ).
  Finally refresh Sugar window in the browser.
  This is necessary in order to "Create Advanced Marketing List from Search" process works correctly, and also in order to generate URLs correctly in bwc mode for DetailView and EditView links in ListView.
  
- If you get Elasticsearch error messages while installing the component, like 'MapperParsingException[Analyzer [gs_analyzer_string] not found for field [gs_string]]' or 'Elastica\Exception\ResponseException' with message 'IndexMissingException ....'
  please, review this community blog entry: https://community.sugarcrm.com/thread/28425. There explains how to re-index your elasticsearch indexes to avoid this problems.
  That is : 
     Navigate to 'Admin > Search' then please follow 'System/Indexing Full Text Search - Administration Guide documentation' (https://support.sugarcrm.com/Documentation/Sugar_Versions/7.7/Ult/Administration_Guide/System/#Indexing_Full_Text_Search).
     IMPORTANT: You would need to click "Delete existing data when index is performed ...".  
     
  
// **************************************//
// IMPORTANT SugarCRM 7.7.2 and later Notes
// **************************************//
  
There is a major bug in SugarCRM 7.7.2 (and probably higher versions) that causes SugarCRM components to not load. 
This error occurs only if we have some value assigned to the php parameter 'upload_tmp_dir'. 
When this error happens, it will not let us upload the component to the Module Loader, and an error appear in sugarcrm.log of type 'File name violation: file outside basedir'.

To solve this problem, either we must assign to 'upload_tmp_dir' php parameter the value returned for the 'sys_get_temp_dir()' function,
or else assign the value that we have in 'upload_tmp_dir' parameter to 'sys_temp_dir' parameter in php.ini.
Second option is available only from php 5.5.0.

See https://community.sugarcrm.com/thread/29009-module-loader-file-outside-basedir
See the bug in the validateFilePath function in /src/Util/Files/FileLoader.php.
  
  
// **************************************//
// Compatibility                         //
// **************************************//

Starting from version 1.1.2, the component is compatible with SugarCRM PRO.
From version 1.1.3 is compatible with SugarCRM On-Demand.

  
//**************************************//
// Known Issues
//**************************************//

- With SugarCRM PRO prior to 7.2 version, menu "Create Advanced Marketing List from Search" in ListView of Contacts, Accounts, Leads, Targets and Users, only appears when you press the search button. 
  With CE and PRO 7.x version this works well.

  
// **************************************//
// Contact                               //
// **************************************//

Izertis
soportedesarrollo@izertis.com
www.sigisoftware.com

