<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$subpanel_layout = array(
   'top_buttons' => array(

   ),

   'where' => '',
   
   'list_fields'=> array(
      'first_name'=>array(
         'usage' => 'query_only',
      ),
      'last_name'=>array(
         'usage' => 'query_only',
      ),
      'full_name'=>array(
         'vname' => 'LBL_LIST_NAME',
         'widget_class' => 'SubPanelDetailViewLink',
         'module' => 'Users',
         'width' => '25%',
      ),
      'user_name'=>array(
         'vname' => 'LBL_LIST_USER_NAME',
         'width' => '25%',
      ),
      'email1'=>array(
         'vname' => 'LBL_LIST_EMAIL',
         'width' => '25%',
         'sortable'=>false,
      ),
      'phone_work'=>array (
         'vname' => 'LBL_LIST_PHONE',
         'width' => '21%',
      ),
   ),
);

?>