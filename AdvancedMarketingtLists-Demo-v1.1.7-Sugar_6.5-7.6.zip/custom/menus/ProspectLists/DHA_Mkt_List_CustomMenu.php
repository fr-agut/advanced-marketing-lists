<?php

if(ACLController::checkAccess('DHA_Mkt_List','list',true)){
   $module_menu[]=Array("index.php?module=DHA_Mkt_List&action=index&return_module=DHA_Mkt_List&return_action=DetailView", 
                        translate('LBL_MODULE_TITLE', 'DHA_Mkt_List'), 
                        "DHA_Mkt_List", 
                        'DHA_Mkt_List'); 
}

?>