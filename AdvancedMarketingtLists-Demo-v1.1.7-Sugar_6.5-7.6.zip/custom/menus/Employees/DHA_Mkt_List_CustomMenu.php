<?php

if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'index' && ACLController::checkAccess('DHA_Mkt_List','edit',true)){
   $module_menu[]=Array("javascript:void(0)\" onclick=\"document.MassUpdate.action.value='EditView'; document.MassUpdate.module.value='DHA_Mkt_List'; document.MassUpdate.submit();", 
                        translate('LBL_CREATE_NEW_ADVANCED_MKT_LIST', 'DHA_Mkt_List'), 
                        "CreateDHA_Mkt_List", 
                        'DHA_Mkt_List'); 
}

?>