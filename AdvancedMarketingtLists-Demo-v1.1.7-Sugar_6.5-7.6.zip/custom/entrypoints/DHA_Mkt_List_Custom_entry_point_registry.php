<?php
//require_once('include\MVC\Controller\entry_point_registry.php');

$entry_point_registry['DHA_SchedulerSaveProspectList'] = array('file' => 'modules/DHA_Mkt_List/SchedulerSaveProspectList.php', 'auth' => false);

?>