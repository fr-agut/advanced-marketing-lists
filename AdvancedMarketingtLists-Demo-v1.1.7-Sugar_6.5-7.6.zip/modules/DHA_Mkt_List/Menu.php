<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 

global $mod_strings, $app_strings, $sugar_config;
 
if(ACLController::checkAccess('DHA_Mkt_List', 'edit', true))$module_menu[]=Array("index.php?module=DHA_Mkt_List&action=EditView&return_module=DHA_Mkt_List&return_action=DetailView", $mod_strings['LNK_NEW_RECORD'], "CreateDHA_Mkt_List", 'DHA_Mkt_List');
if(ACLController::checkAccess('DHA_Mkt_List', 'list', true))$module_menu[]=Array("index.php?module=DHA_Mkt_List&action=index&return_module=DHA_Mkt_List&return_action=DetailView", $mod_strings['LNK_LIST'], "DHA_Mkt_List", 'DHA_Mkt_List');
if(ACLController::checkAccess('DHA_Mkt_List', 'import', true))$module_menu[]=Array("index.php?module=Import&action=Step1&import_module=DHA_Mkt_List&return_module=DHA_Mkt_List&return_action=index", $app_strings['LBL_IMPORT'], "Import", 'DHA_Mkt_List');