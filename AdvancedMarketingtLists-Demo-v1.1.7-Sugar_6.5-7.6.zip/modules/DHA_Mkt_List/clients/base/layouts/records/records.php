<?php

$viewdefs['DHA_Mkt_List']['base']['layout']['records'] = array (
   'name' => 'bwc',
   'type' => 'bwc',
   'components' => array (
      array (
         'view' => 'bwc',
      ),
   ),
);

