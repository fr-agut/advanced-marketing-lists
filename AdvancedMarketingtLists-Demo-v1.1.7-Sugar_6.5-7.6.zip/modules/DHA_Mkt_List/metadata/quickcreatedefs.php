<?php

require ('modules/DHA_Mkt_List/metadata/editviewdefs.php');  

$viewdefs ['DHA_Mkt_List']['QuickCreate'] = $viewdefs ['DHA_Mkt_List']['EditView'];

?>
