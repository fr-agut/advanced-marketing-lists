<?php
$module_name='DHA_Mkt_List';
$subpanel_layout = array (
   'top_buttons' => 
   array (
      0 => 
      array (
         'widget_class' => 'SubPanelTopCreateButton',
      ),
      1 => 
      array (
         'widget_class' => 'SubPanelTopSelectButton',
         'popup_module' => 'DHA_Mkt_List',
      ),
   ),
   'where' => '',
   'list_fields' => 
   array (
      'name' =>  array (
         'vname' => 'LBL_NAME',
         'widget_class' => 'SubPanelDetailViewLink',
         'width' => '45%',
         'default' => true,
      ),
      'edit_button' => array (
         'widget_class' => 'SubPanelEditButton',
         'module' => 'DHA_Mkt_List',
         'width' => '4%',
         'default' => true,
      ),
      'remove_button' => array (
         'widget_class' => 'SubPanelRemoveButton',
         'module' => 'DHA_Mkt_List',
         'width' => '5%',
         'default' => true,
      ),
   ),
);