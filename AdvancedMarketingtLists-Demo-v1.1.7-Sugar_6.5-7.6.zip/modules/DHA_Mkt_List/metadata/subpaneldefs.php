<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

   global $mod_strings;

   $layout_defs["DHA_Mkt_List"]["subpanel_setup"]["dha_mkt_lists_prospectlists"] = array (
     'order' => 100,
     'module' => 'ProspectLists',
     'subpanel_name' => 'default',
     'sort_order' => 'asc',
     'sort_by' => 'name',
     'title_key' => 'LBL_PANEL_PROSPECTLISTS',
     'get_subpanel_data' => 'prospectlists',
     'top_buttons' => 
     array (

     ),
   );


   // Nota: no se controlan permisos sobre la tabla, porque Sugar ya se encarga de hacer esa comprobaci�n en los subpaneles   
   if (isset($this->_focus->sql_prospects) && $this->_focus->sql_prospects) {
      $layout_defs["DHA_Mkt_List"]["subpanel_setup"]["dha_mkt_list__prospects"] = array (
        'order' => 10003,
        'module' => 'Prospects',
        'subpanel_name' => 'ForDHA_Mkt_List', //'default',
        'sort_order' => 'asc',
        'sort_by' => 'last_name, first_name',
        'title_key' => "<p style='color:red;'>{$mod_strings['LBL_PANEL_PROSPECTS']}</p>",  
        'get_subpanel_data' => 'function:get_mkt_list_subpanel_query',
        'generate_select'=> true,
        'function_parameters' => array('return_as_array' => true, 
                                       'import_function_file' => 'modules/DHA_Mkt_List/subpanel_functions.php', 
                                       'table' => 'prospects', 
                                       'id' => $this->_focus->id, 
                                       'sql' => $this->_focus->sql_prospects),
        'top_buttons' => 
         array (
         
         ),
      );
   }    

   // Nota: no se controlan permisos sobre la tabla, porque Sugar ya se encarga de hacer esa comprobaci�n en los subpaneles   
   if (isset($this->_focus->sql_users) && $this->_focus->sql_users) {
      $layout_defs["DHA_Mkt_List"]["subpanel_setup"]["dha_mkt_list__users"] = array (
        'order' => 10004,
        'module' => 'Users',
        'subpanel_name' => 'ForDHA_Mkt_List', //'default',
        'sort_order' => 'asc',
        'sort_by' => 'full_name', //'last_name, first_name',
        'title_key' => "<p style='color:red;'>{$mod_strings['LBL_PANEL_USERS']}</p>", 
        'get_subpanel_data' => 'function:get_mkt_list_subpanel_query',
        'generate_select'=> true,
        'function_parameters' => array('return_as_array' => true, 
                                       'import_function_file' => 'modules/DHA_Mkt_List/subpanel_functions.php', 
                                       'table' => 'users', 
                                       'id' => $this->_focus->id, 
                                       'sql' => $this->_focus->sql_users),
        'top_buttons' => 
         array (
         
         ),
      );
   }     

?>
