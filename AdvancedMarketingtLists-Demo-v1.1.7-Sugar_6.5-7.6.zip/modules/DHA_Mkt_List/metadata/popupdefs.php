<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$module_name = 'DHA_Mkt_List';
$object_name = 'DHA_Mkt_List';
$_module_name = 'dha_mkt_list';
$popupMeta = array(
   'moduleMain' => $module_name,
   'varName' => $object_name,
   'orderBy' => $_module_name.'.name',
   'whereClauses' => array('name' => $_module_name . '.name'),
   'searchInputs'=> array('name'),
                     
);

?>
 
 