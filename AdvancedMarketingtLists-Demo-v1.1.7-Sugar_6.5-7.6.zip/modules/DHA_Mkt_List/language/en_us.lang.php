<?php

global $app_list_strings, $app_strings;

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'User',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_FORM_TITLE' => 'Advanced Marketing List',
  'LBL_MODULE_NAME' => 'Advanced Marketing List',
  'LBL_MODULE_TITLE' => 'Advanced Marketing List',
  'LBL_HOMEPAGE_TITLE' => 'My Advanced Marketing Lists',
  'LNK_NEW_RECORD' => 'Create Advanced Marketing List',
  'LNK_LIST' => 'View Advanced Marketing List',
  'LNK_IMPORT_DHA_Advanced Marketing List' => 'Import Advanced Marketing List',
  'LBL_SEARCH_FORM_TITLE' => 'Search Advanced Marketing List',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_DHA_MKT_LIST_SUBPANEL_TITLE' => 'Advanced Marketing List',
  'LBL_NEW_FORM_TITLE' => 'New Advanced Marketing List',
  'LBL_SQL_PROSPECTS' => 'Targets SQL',
  'LBL_SQL_USERS' => 'Users SQL',
  'LBL_MODULES' => 'Modules',
  'LBL_CREATE_NEW_ADVANCED_MKT_LIST' => 'Create Advanced Marketing List from Search',
  
  'LBL_PANEL_SCHEDULER' => 'Scheduler',  
  'LBL_SCHEDULER' => 'Scheduler',  
  'LBL_CREATE_SCHEDULER' => 'Create Scheduler',  
  'LBL_VIEW_SCHEDULER' => 'View Scheduler',  
  'LBL_DEFAULT_PROSPECT_LIST' => 'Target List',    
  'LBL_ONLY_FOR_SCHEDULERS' => 'Only for Schedulers',  
  'LBL_SCHEDULER_URL' => 'URL for Schedulers',    
  
  'LBL_REGENERAR_LISTA_PUBLICO_OBJETIVO' => 'Regenerate Target List', 
  'LBL_REGENERAR_LISTA_PUBLICO_OBJETIVO_HELP' => 'Checking this option will delete the content and will fully generate the selected Target list in process "'.$app_strings['LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL'].'"',    
  
  'LBL_ETIQUETA_INSTRUCCIONES_LISTVIEW' => 'Instructions',
  'LBL_TEXTO_INSTRUCCIONES_LISTVIEW' => 'If process "{0}" is run from the ListView, it will get the field value "{1}" that matches in all the selected records.<br />
If any of them had a different value from the others, it will be assumed that "{2}" it is checked for all the selected records.',
  
  'LBL_PANEL_SQL' => 'SQL',
  'LBL_PANEL_PROSPECTLISTS' => 'Modified Target Lists', 
  'LBL_PANEL_PROSPECTS' => 'Targets',
  'LBL_PANEL_USERS' => 'Users',
  
  'LBL_ERROR_SQL_EXECUTE' => 'SQL for Module "{0}" has errors.',
  'LBL_SQL_RULES' => '<br />The SQL must meet the following conditions:<br />
- SQL with INSERT or DELETE type actions are not supported. Only SELECT type SQL.<br />
- The SELECT statement must always be on the table with the corresponding field of SQL.<br />
- The sentence should only return the field "id" in the table with the corresponding field of SQL.<br />
- The SQL cannot contain a "ORDER BY" clause.<br />
- The SQL should run without errors.<br />',

);
?>
