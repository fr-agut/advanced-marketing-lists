<?php

global $sugar_config;
$en_us_lang = 'en_us';
$es_es_lang = 'es_es';
foreach ($sugar_config['languages'] as $lang_key => $lang_label) {
   $lower_lang_key = strtolower($lang_key);
   if ($lower_lang_key ==  $en_us_lang)
      $en_us_lang = $lang_key;
   if ($lower_lang_key ==  $es_es_lang)
      $es_es_lang = $lang_key;
}


$manifest = array(
   // Valido a partir de la 6.5.6 
   'acceptable_sugar_versions' => array (  
      'regex_matches' => array (   
         0 => "6\.5\.[6789]",
         1 => "6\.5\.1\d",
         2 => "7\.2\.*",
      ),
   ),
   'acceptable_sugar_flavors' => array (
      0 => 'CE',
      1 => 'PRO',
      2 => 'CORP',
      3 => 'ENT',
      4 => 'ULT',
   ),
   'is_uninstallable' => true,
   'remove_tables' => 'prompt',
   'key' => 'DHA',
   'name' => 'Advanced Marketing List Demo',
   'description' => 'Keep Target Lists automatically updated (Demo)',
   'author' => 'Izertis',
   'published_date' => '2014/07/25',
   'version' => '1.1.4',
   'type' => 'module',
   'icon' => '',
);

// Nota: Ver el fichero ModuleInstall/extensions.php para la lista de extensiones disponibles (fijarse en el parametro 'section')
//       Ver tambien las funciones install_extensions y installExt (esta última especialmente) en ModuleInstall/ModuleInstaller.php

$installdefs = array(
   'id' => 'AdvancedMarketingList',
   'image_dir' => '<basepath>/icons',
   
   // 'mkdir' => array(
      // '/document_templates/',
   // ),   
   
   'beans' => array(
      array(
         'module'          => 'DHA_Mkt_List',
         'class'           => 'DHA_Mkt_List',
         'path'            => 'modules/DHA_Mkt_List/DHA_Mkt_List.php',
         'tab'             => true, 
      )
   ),
   
   'vardefs' => array (
      array(
         'from' => '<basepath>/custom/vardefs/dha_mkt_lists_prospectlists.php',
         'to_module' => 'ProspectLists',
      ),
   ),  

  'relationships' => array (
      array(
         'meta_data' => '<basepath>/custom/relationships/dha_mkt_lists_prospectlistsMetaData.php',
      ),
   ),  

  'entrypoints' => array (
      array(
         'from' => '<basepath>/custom/entrypoints/DHA_Mkt_List_Custom_entry_point_registry.php',
         'to_module' => 'application',         
      ),
   ),     
   
   'language' => array(
      array(
         'from'      => '<basepath>/language/en_us.AdvancedMarketingList.php',
         'to_module' => 'application',
         'language'  => $en_us_lang
      ),
      array(
         'from'      => '<basepath>/language/es_es.AdvancedMarketingList.php',
         'to_module' => 'application',
         'language'  => $es_es_lang
      ),
   ),
   
  'layoutdefs'  => array(
   ),
   
   'menu' => array(
      array(
         'from'      => '<basepath>/custom/menus/Employees/DHA_Mkt_List_CustomMenu.php',
         'to_module' => 'Employees',
      ), 
      array(
         'from'      => '<basepath>/custom/menus/Users/DHA_Mkt_List_CustomMenu.php',
         'to_module' => 'Users',
      ),      
      array(
         'from' => '<basepath>/custom/menus/Prospects/DHA_Mkt_List_CustomMenu.php',
         'to_module' => 'Prospects',
      ),      
      array(
         'from' => '<basepath>/custom/menus/ProspectLists/DHA_Mkt_List_CustomMenu.php',
         'to_module' => 'ProspectLists',
      ), 
   ),   
   
   'copy' => array(
      array(
         'from' => '<basepath>/modules/DHA_Mkt_List',
         'to'   => 'modules/DHA_Mkt_List',
      ),
      array(
         'from' => '<basepath>/README.txt',
         'to'   => 'modules/DHA_Mkt_List/README.txt',         
      ),      
      
      array(
         'from' => '<basepath>/custom/subpanels/Users/ForDHA_Mkt_List.php',
         'to'   => 'custom/modules/Users/metadata/subpanels/ForDHA_Mkt_List.php',
      ),
      array(
         'from' => '<basepath>/custom/subpanels/Prospects/ForDHA_Mkt_List.php',
         'to'   => 'custom/modules/Prospects/metadata/subpanels/ForDHA_Mkt_List.php',
      ),
      
      array(  
         'from' => '<basepath>/custom/Extension/application/Ext/Include/DHA_Mkt_List_Custom_extensions.php',
         'to'   => 'custom/Extension/application/Ext/Include/DHA_Mkt_List_Custom_extensions.php',
      ),        
   ),
     
   
   // Si el directorio "actions" se llamara "scripts" y los nombres de los ficheros son los standard, esto no sería necesario.
   // Si se hace como "scripts" el codigo de los ficheros debe de estar encapsulado en funciones (pre_install(), post_install(), etc.),
   // pero si se hace declarandolos en el manifest.php (como aqui) el código no se tiene que encapsular en funciones.
   // Otra diferencia es que si lo hacemos como "scripts", y el manifest es de un módulo, no se ejecuta el script de post_uninstall (el código no lo llama para ese caso)
   
   'pre_execute' => array(
      0 => '<basepath>/actions/pre_install.php',
   ),
   
   'post_execute' => array(
      0 => '<basepath>/actions/post_install.php',
   ),
   
   'pre_uninstall' => array(
      0 => '<basepath>/actions/pre_uninstall.php',
   ),
   
   'post_uninstall' => array(
      0 => '<basepath>/actions/post_uninstall.php',
   ),

);

/* if (!preg_match('/^6|(5\.(?>[2-9]|1\.0[a-z]))/', $GLOBALS['sugar_version']))
      $installdefs['copy'][] =
                  array('from'    => '<basepath>/modules/ModuleBuilder/views/view.modulefield.php',
                        'to'      => 'modules/ModuleBuilder/views/view.modulefield.php',
               ); */
                
?>
