<?php


// Relaci�n con el modulo DHA_Mkt_List (subpanel en DHA_Mkt_List)
$dictionary["ProspectList"]["fields"]["dha_mkt_lists"] = array (
  'name' => 'dha_mkt_lists',
  'type' => 'link',
  'relationship' => 'dha_mkt_lists_prospectlists',  
  'source' => 'non-db',
);

//  Relaci�n con el modulo DHA_Mkt_List, campo de Lista de Publico Objetivo por defecto 
$dictionary["ProspectList"]["fields"]["dha_mkt_lists_def"] = array (
  'name' => 'dha_mkt_lists_def',
  'type' => 'link',
  'relationship' => 'prospectlist_dha_mkt_lists_rel', 
  'source' => 'non-db',
);



?>
