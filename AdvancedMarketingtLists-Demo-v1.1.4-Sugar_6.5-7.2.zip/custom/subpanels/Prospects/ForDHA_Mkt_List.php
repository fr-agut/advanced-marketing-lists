<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$subpanel_layout = array(
   'top_buttons' => array(

   ),

   'where' => '',

    'list_fields'=> array(
      'first_name' => array(
         'usage' => 'query_only',
      ),
      'last_name' => array(
         'usage' => 'query_only',
      ),
         'full_name'=>array(
         'vname' => 'LBL_LIST_NAME',
         'widget_class' => 'SubPanelDetailViewLink',
         'width' => '40%',
         'sort_by' => 'last_name',
      ),
      'title'=>array(
         'vname' => 'LBL_LIST_TITLE',
         'width' => '25%',
      ),
      'email1'=>array(
         'vname' => 'LBL_LIST_EMAIL_ADDRESS',
         'width' => '15%',
         'widget_class' => 'SubPanelEmailLink',
         'sortable' => false,
      ),
      'phone_work'=>array(
         'vname' => 'LBL_LIST_PHONE',
         'width' => '10%',
      ),
   ),
);

?>