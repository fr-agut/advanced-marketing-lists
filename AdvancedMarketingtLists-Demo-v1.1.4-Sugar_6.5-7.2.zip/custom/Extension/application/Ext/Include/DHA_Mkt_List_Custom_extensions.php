<?php 

global $sugar_version;
if (version_compare($sugar_version, '7.1.0', '>=')) {
   $bwcModules[] = 'DHA_Mkt_List';
}

?>