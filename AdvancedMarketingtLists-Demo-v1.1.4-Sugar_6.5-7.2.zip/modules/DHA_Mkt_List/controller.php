<?php

require_once('include/MVC/Controller/SugarController.php');
  
class DHA_Mkt_ListController extends SugarController {

   ///////////////////////////////////////////////////////////////////////////
   function action_SaveProspectList(){
      // Para llamadas desde el botón del DetailView
      
      global $current_user;
      
      $this->view = '';
      $GLOBALS['view'] = ''; 

      $id_mkt_list = $_REQUEST['id_mkt_list'];
      $id_prospect_list = $_REQUEST['id_prospect_list'];      

      $bean_ProspectLists = SugarModule::get('ProspectLists')->loadBean();
      $bean_Mkt_List = SugarModule::get('DHA_Mkt_List')->loadBean();
      
      $bean_ProspectLists->retrieve($id_prospect_list);
      
      $is_owner = true;
      if ($current_user->id) {
         $is_owner = $bean_ProspectLists->isOwner($current_user->id);
      }
      
      if(!$bean_ProspectLists->ACLAccess('edit', $is_owner)){
         ACLController::displayNoAccess(true);
         sugar_cleanup(true);
      }
      
      $OK = $bean_Mkt_List->SaveProspectList($id_mkt_list, $id_prospect_list);
      
      if ($OK)
         $dURL = "index.php?module=ProspectLists&action=DetailView&record={$id_prospect_list}";
      else
         $dURL = "index.php?module=DHA_Mkt_List&action=DetailView&record={$id_mkt_list}";      
      SugarApplication::redirect($dURL);
   }


   ///////////////////////////////////////////////////////////////////////////
   function action_CreateScheduler(){
      // Para crear un planificador
      
      $this->view = '';
      $GLOBALS['view'] = ''; 
      
      if (!isset($_REQUEST['record']) || !$_REQUEST['record'])
         SugarApplication::redirect('index.php');    
      
      $id_mkt_list = $_REQUEST['record'];      
      
      $bean_Mkt_List = SugarModule::get('DHA_Mkt_List')->loadBean();
      $id_Scheduler = $bean_Mkt_List->CreateScheduler($id_mkt_list);
      
      if ($id_Scheduler)
         $dURL = "index.php?module=Schedulers&action=DetailView&record={$id_Scheduler}";
      else
         $dURL = "index.php?module=DHA_Mkt_List&action=DetailView&record={$id_mkt_list}";      
      SugarApplication::redirect($dURL);
   }  


   ///////////////////////////////////////////////////////////////////////////
   function action_ValidateSQL(){
      // Para llamadas Ajax de validaciones de las SQL

      $this->view = '';
      $GLOBALS['view'] = '';       
      
      $sql = from_html($_REQUEST['sql']);
      $field_name = $_REQUEST['field_name'];
      
      $mensaje = '';
      
      if ($sql) {
         $bean_Mkt_List = SugarModule::get('DHA_Mkt_List')->loadBean();
         $mensaje = $bean_Mkt_List->ValidateSQL($field_name, $sql);
      }

      echo $mensaje;
      return true;
   }   
   
}
?>
