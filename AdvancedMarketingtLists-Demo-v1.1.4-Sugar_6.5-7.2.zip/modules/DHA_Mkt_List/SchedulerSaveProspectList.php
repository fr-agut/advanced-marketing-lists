<?php
   if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

   function Scheduler_SaveProspectList() {
      global $current_user;
      
      if (!isset($_REQUEST['record']) || !$_REQUEST['record'])
         return false;      
      
      $id_mkt_list = $_REQUEST['record'];
      
      $user_id = $GLOBALS['current_user']->id;

      if (!$user_id && isset($_SESSION['authenticated_user_id']) && $_SESSION['authenticated_user_id']) {
         $user_id = $_SESSION['authenticated_user_id'];
      }
      
      if (!$user_id) {
         $sql = " SELECT id
                  FROM users
                  WHERE is_admin = 1 AND deleted = 0 and status = 'Active'
                  LIMIT 1 ";
         $user_id = $GLOBALS['db']->getOne($sql);
      }      
      
      if (!$user_id) {
         return false;
      }
      
      $GLOBALS['current_user']->retrieve($user_id);
      
      $sql = " SELECT t1.def_prospect_list_id
               FROM dha_mkt_list t1 
               INNER JOIN prospect_lists t2
                  ON t2.id =  t1.def_prospect_list_id
               WHERE t1.id = '{$id_mkt_list}' AND t1.deleted = 0 AND t2.deleted = 0 ";      
      $id_prospect_list = $GLOBALS['db']->getOne($sql);
      if ($id_prospect_list === false) {
         return false;     
      }

      $bean_ProspectLists = SugarModule::get('ProspectLists')->loadBean();
      $bean_Mkt_List = SugarModule::get('DHA_Mkt_List')->loadBean();
      
      $bean_ProspectLists->retrieve($id_prospect_list);
      
      $is_owner = true;
      if ($user_id) {
         $is_owner = $bean_ProspectLists->isOwner($user_id);
      }
      
      if(!$bean_ProspectLists->ACLAccess('edit', $is_owner)){
         return false;
      }
      
      $OK = $bean_Mkt_List->SaveProspectList($id_mkt_list, $id_prospect_list);

      return $OK;
   }
   
   
   
   $GLOBALS['log']->debug('----->Entrando en SchedulerSaveProspectList');   

   $OK = Scheduler_SaveProspectList();
   
   if ($OK) {
      $GLOBALS['log']->debug('----->Saliendo de SchedulerSaveProspectList - OK'); 
   }
   else {
      $GLOBALS['log']->debug('----->Saliendo de SchedulerSaveProspectList - Ha habido algún error');    
   }
   
   echo $OK;
?>
