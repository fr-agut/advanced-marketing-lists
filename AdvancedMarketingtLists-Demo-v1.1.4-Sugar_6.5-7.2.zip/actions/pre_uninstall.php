<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//function pre_uninstall() {

//}

?>