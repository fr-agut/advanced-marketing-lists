<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

//function post_install() {
   
   if ($_REQUEST['mode'] == 'Install') {

   }

//}

?>

