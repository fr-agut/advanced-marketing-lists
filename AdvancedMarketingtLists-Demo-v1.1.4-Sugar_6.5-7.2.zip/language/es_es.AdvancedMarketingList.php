
<?php

$app_list_strings['moduleList']['DHA_Mkt_List'] = 'Listas Marketing Avanzado';

$app_list_strings['dha_mkt_list_module_list']=array (
  '' => '',
  'Prospects' => 'Público Objetivo',
  'Users' => 'Usuarios',
);


